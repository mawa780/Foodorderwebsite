<?php
    //
    include('config/constants.php');
    //1.
    session_destroy(); //

    //2.
    header('location:'.SITEURL.'admin/login.php');
?>