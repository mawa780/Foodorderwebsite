<?php
    include('config/constants.php');
    $id=$_GET['id'];
    $sql = "DELETE FROM tbl_admin Where id=$id";
    $res = mysqli_query($conn, $sql);
    if($res==true)
    {
        //echo "Admin Deleted";
        $_SESSION['delete']="<div class='success'>Admin deleted successfully.</div>";
        header('location:'.SITEURL.'admin/manage-admin.php');
    }
    else
    {
        //echo "Failed to delete admin";
        $_SESSION['delete']="<div class='error'Failed to delete admin.Try again later.</div>";
        header('location:'.SITEURL.'admin/manage-admin.php');

    }
?>