<!--footer Section Starts-->
<div class="footer">
	        <div class="wrapper">
                <p class="text-center">Food House<a href="#"></a></p>
        </div>
	    </div>
        <!--footer Section Ends-->
       

    </body>
</html>
        
      